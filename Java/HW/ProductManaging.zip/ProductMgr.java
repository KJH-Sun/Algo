package com.ssafy.hw0122;

import java.util.Arrays;

public class ProductMgr {
	int size = 4;
	int pos = 0;
	Product[] parray = new Product[size];

	public void add(Product p) {
		if (pos == size) {
			Arrays.copyOf(parray, size * 2);
			size = size * 2;
		}
		parray[pos] = p;
		pos++;
	}

	public Product[] list() {
		return Arrays.copyOf(parray, pos);
	}

	public Product list(int pNum) {
		for (int i = 0; i < pos; i++) {
			if (pNum == parray[i].getpNum()) {
				return parray[i];
			}
		}
		return null;
	}

	public boolean delete(int pNum) {

		for (int i = 0; i < pos; i++) {
			if (pNum == parray[i].getpNum()) {
				int movecnt = pos - i - 1;
				System.arraycopy(parray, i + 1, parray, i, movecnt);
				pos--;
				return true;
			}
		}
		return false;

	}

	public Product[] priceList(int price) {
		Product[] cheap = new Product[size];
		int cheapcount = 0;
		for (int i = 0; i < pos; i++) {
			if (parray[i].getPrice() < price) {
				cheap[cheapcount] = parray[i];
				cheapcount++;
			}
		}
		return Arrays.copyOf(cheap, cheapcount);
	}

}
