package com.ssafy.hw0122;

import java.util.Scanner;

public class ProductTest {
	static Scanner sc = new Scanner(System.in);

	int menu() {
		System.out.println("메뉴를 선택하세요");
		System.out.println("1. 상품 저장");
		System.out.println("2. 저장 상품 출력");
		System.out.println("3. 상품 검색");
		System.out.println("4. 상품 삭제");
		System.out.println("5. 가격 미만 제품 출력");
		System.out.println("0. 종료");

		return Integer.parseInt(sc.nextLine());
	}

	String getString(String msg) {
		System.out.println(msg);
		return (sc.nextLine());
	}

	int getInt(String msg) {
		System.out.println(msg);
		return (Integer.parseInt(sc.nextLine()));
	}

	void exit() {
		System.exit(0);
	}

	public static void main(String[] args) {
		ProductTest pt = new ProductTest();
		ProductMgr pm = new ProductMgr();

		while (true) {
			switch (pt.menu()) {
			case 1:
				pm.add(new Product(pt.getInt("제품번호를 입력해주세요"), pt.getString("제품명을 입력해주세요"), pt.getInt("가격을 입력해주세요"),
						pt.getInt("수량을 입력해주세요"), pt.getString("상세설명을 입력해주세요")));
				break;
			case 2:
				System.out.println("***************제품목록******************");
				System.out.println("제품번호 \t 제품이름 \t 제품가격 \t 수량 \t 상세설명");
				for (Product p : pm.list()) {
					System.out.println(p);
				}
				break;
			case 3:
				System.out.println(pm.list(pt.getInt("검색하려는 제품 번호를 입력해주세요.")));
				break;
			case 4:
				if (pm.delete(pt.getInt("삭제하려는 제품의 번호를 입력해주세요."))) {
					System.out.println("삭제되었습니다.");
				} else {
					System.out.println("없는 제품번호입니다.");
				}
				break;
			case 5:
				for (Product p : pm.priceList(pt.getInt("입력하는 가격 이하의 제품들을 출력합니다."))) {
					System.out.println(p);
				}

				break;
			case 0:
				pt.exit();

			}

		}

	}

}
